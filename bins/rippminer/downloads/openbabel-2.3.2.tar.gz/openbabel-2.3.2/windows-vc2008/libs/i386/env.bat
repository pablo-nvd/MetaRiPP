set PATH=%CD%;%PATH%
